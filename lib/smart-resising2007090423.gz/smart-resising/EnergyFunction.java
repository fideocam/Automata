/**
 * Auteur : Pierre-Francois L�on (leon(at)sic.univ-poitiers.fr)
 * 
 * Implantation bourrin en Java de l'article "Seam Carving for Content-Aware Image Resizing" (Shai Avidan, Ariel Shamir)
 */

import java.awt.image.*;

abstract class EnergyFunction {
    abstract public int[][] compute(BufferedImage i);

    public BufferedImage computeToImage(BufferedImage img) {
        BufferedImage res = new BufferedImage(img.getWidth(),
			                      img.getHeight(),
					      img.getType());
	
	int t[][] = compute(img);

	int v;
	for (int i = 0; i < img.getWidth(); ++i)
	    for (int j = 0; j < img.getHeight(); ++j) {
		v = t[i][j];
		res.setRGB(i, j, v + (v << 8) + (v << 16));
	    }
	
	return res;
    }

    public BufferedImage energyToImage(int e[][]) {
	BufferedImage res = new BufferedImage(e.length, 
					      e[0].length, 
					      BufferedImage.TYPE_INT_RGB);
	
	int v;
	for (int i = 0; i < e.length; ++i)
	    for (int j = 0; j < e[0].length; ++j) {
		v = e[i][j];
		res.setRGB(i, j, v + (v << 8) + (v << 16));
	    }
	
	return res;
    }
}
