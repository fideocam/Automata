/**
 * Auteur : Pierre-Francois L�on (leon(at)sic.univ-poitiers.fr)
 * 
 * Implantation bourrin en Java de l'article "Seam Carving for Content-Aware Image Resizing" (Shai Avidan, Ariel Shamir)
 */

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;

import javax.swing.*;
import javax.imageio.*;

import java.io.*;

class SmartResizing extends JPanel {
    String m_filename;
    BufferedImage m_img;
    Image m_energy_img;
    
    EnergyFunction m_ef;
    int m_energy[][];
    boolean m_mustShowEnergy;

    public SmartResizing(String filename, EnergyFunction ef) {
	m_filename = filename;
	try {
	    m_img = ImageIO.read(new FileInputStream(filename));
	} catch (Exception e) {
	    JOptionPane.showMessageDialog(null, e.toString(), "Error", JOptionPane.ERROR_MESSAGE);
	    System.err.println(e);
	    System.exit(1);
	}

	addComponentListener(new defaultComponentAdapter());

	setPreferredSize(new Dimension(m_img.getWidth(),
				       m_img.getHeight()));

	m_ef = ef;

	update();

	m_mustShowEnergy = false;
    }

    public void setEnergyFunction(EnergyFunction ef) {
	m_ef = ef;
	update();
    }

    public void update() {
	update(true, true);
    }

    public void update(boolean computeenergy) {
	update(computeenergy, true);
    }

    public void update(boolean computeenergy, boolean r) {
	if (computeenergy) {
	    m_energy = m_ef.compute(m_img);
	}

	if (m_mustShowEnergy) {
	    if (m_energy == null) m_energy = m_ef.compute(m_img);
	    m_energy_img = m_ef.energyToImage(m_energy).getScaledInstance(m_img.getWidth() / 4, m_img.getHeight() / 4, Image.SCALE_FAST);
	}

	if (r)
	    repaint();
    }
    
    public void toogleShowEnergyImage() {
	m_mustShowEnergy = !m_mustShowEnergy;
	update(false, true);
    }

    /// res[x][y][0] = prevy
    /// res[x][y][1] = seanenergy
    public int[][][] computeHSeanCost() {
	int h = m_img.getHeight() - 2;
	int w = m_img.getWidth() - 2;

	int res[][][] = new int[w][h][2];

	for (int j = 0; j < h; ++j)
	    res[0][j][1] = m_energy[0][j];

	for (int i = 1; i < w; ++i) {
	    for (int j = 0; j < h; ++j) {
		int curEnergy = m_energy[i][j];

		int prevY;
		if (j != 0 && j != h - 1) {
		    int a = res[i - 1][j - 1][1];
		    int b = res[i - 1][j    ][1];
		    int c = res[i - 1][j + 1][1];

		    if (a < b && a < c) { /// min = a
			res[i][j][0] = j - 1;
			res[i][j][1] = a + curEnergy;
		    } else if (c < a && c < b) { /// min = c
			res[i][j][0] = j + 1;
			res[i][j][1] = c + curEnergy;
		    } else {  /// min = b
			res[i][j][0] = j;
			res[i][j][1] = b + curEnergy;
		    }
		} else if (j == 0) {
		    int b = res[i - 1][j    ][1];
		    int c = res[i - 1][j + 1][1];
		    if (c < b) { /// min = c
			res[i][j][0] = j + 1;
			res[i][j][1] = c + curEnergy;
		    } else {  /// min = b
			res[i][j][0] = j;
			res[i][j][1] = b + curEnergy;
		    }
		} else { // j == j - 1
		    int a = res[i - 1][j - 1][1];
		    int b = res[i - 1][j    ][1];

		    if (a < b) { /// min = a
			res[i][j][0] = j - 1;
			res[i][j][1] = a + curEnergy;
		    } else {  /// min = b
			res[i][j][0] = j;
			res[i][j][1] = b + curEnergy;
		    }
		}
	    }
	}

	return res;
    }

    public int[] findHSeanWithLowerCost() {
	int h = m_img.getHeight() - 2;
	int w = m_img.getWidth() - 2;
	int sean[][][] = computeHSeanCost();

	int l = 0;
	for (int j = 0; j < h; ++j) {
	    if (sean[w - 1][j][1] < sean[w - 1][l][1])
		l = j;
	}

	int res[] = new int[w + 2];

	res[w + 1] = l;
	for (int i = w; i > 0; --i) {
	    res[i] = l + 1;
	    l = sean[i - 1][l][0];
	}
	res[0] = l;

	return res;
    }

    public void removeh() {
	BufferedImage in = new BufferedImage(m_img.getWidth(), 
					     m_img.getHeight() - 1, 
					     m_img.getType());
	
	int sean[] = findHSeanWithLowerCost();

	Graphics g = getGraphics();
	g.setColor(Color.RED);
	for (int i = 0; i < m_img.getWidth(); ++i) {
	    g.drawLine(i, sean[i], i, sean[i]);
	}

	// suppression de la ligne...
	for (int i = 0; i < m_img.getWidth(); ++i) {
	    for (int j = 0; j < m_img.getHeight(); ++j) {
		if (j > sean[i])
		    in.setRGB(i, j - 1, m_img.getRGB(i, j));
		else if (j < sean[i])
		    in.setRGB(i, j, m_img.getRGB(i, j));
	    }
	}

	m_img = in;

	setPreferredSize(new Dimension(m_img.getWidth(),
				       m_img.getHeight()));


	update(true, false);
    }
    
    /// res[x][y][0] = prevx
    /// res[x][y][1] = seanenergy
    public int[][][] computeVSeanCost() {
	int h = m_img.getHeight() - 2;
	int w = m_img.getWidth() - 2;

	int res[][][] = new int[w][h][2];

	for (int i = 0; i < w; ++i)
	    res[i][0][1] = m_energy[i][0];

	
	for (int j = 1; j < h; ++j) {
	    for (int i = 0; i < w; ++i) {
		int curEnergy = m_energy[i][j];

		int prevY;
		if (i != 0 && i != w - 1) {
		    int a = res[i - 1][j - 1][1];
		    int b = res[i    ][j - 1][1];
		    int c = res[i + 1][j - 1][1];

		    if (a < b && a < c) { /// min = a
			res[i][j][0] = i - 1;
			res[i][j][1] = a + curEnergy;
		    } else if (c < a && c < b) { /// min = c
			res[i][j][0] = i + 1;
			res[i][j][1] = c + curEnergy;
		    } else {  /// min = b
			res[i][j][0] = i;
			res[i][j][1] = b + curEnergy;
		    }
		} else if (i == 0) {
		    int b = res[i    ][j - 1][1];
		    int c = res[i + 1][j - 1][1];
		    if (c < b) { /// min = c
			res[i][j][0] = i + 1;
			res[i][j][1] = c + curEnergy;
		    } else {  /// min = b
			res[i][j][0] = i;
			res[i][j][1] = b + curEnergy;
		    }
		} else { // j == j - 1
		    int a = res[i - 1][j - 1][1];
		    int b = res[i    ][j - 1][1];

		    if (a < b) { /// min = a
			res[i][j][0] = i - 1;
			res[i][j][1] = a + curEnergy;
		    } else {  /// min = b
			res[i][j][0] = i;
			res[i][j][1] = b + curEnergy;
		    }
		}
	    }
	}

	return res;
    }

    public int[] findVSeanWithLowerCost() {
	int h = m_img.getHeight() - 2;
	int w = m_img.getWidth() - 2;
	int sean[][][] = computeVSeanCost();

	int l = 0;
	for (int i = 0; i < w; ++i) {
	    if (sean[i][h - 1][1] < sean[l][h - 1][1])
		l = i;
	}

	int res[] = new int[h + 2];

	res[h + 1] = l;
	for (int j = h; j > 0; --j) {
	    res[j] = l + 1;
	    l = sean[l][j - 1][0];
	}
	res[0] = l;

	return res;
    }

    public void removev() {
	BufferedImage in = new BufferedImage(m_img.getWidth() - 1, 
					     m_img.getHeight(), 
					     m_img.getType());
	
	int sean[] = findVSeanWithLowerCost();

	Graphics g = getGraphics();
	g.setColor(Color.RED);
	for (int j = 0; j < m_img.getHeight(); ++j) {
	    g.drawLine(sean[j], j, sean[j], j);
	}

	// suppression de la ligne...
	for (int i = 0; i < m_img.getWidth(); ++i) {
	    for (int j = 0; j < m_img.getHeight(); ++j) {
		if (i > sean[j])
		    in.setRGB(i - 1, j, m_img.getRGB(i, j));
		else if (i < sean[j])
		    in.setRGB(i, j, m_img.getRGB(i, j));
	    }
	}

	m_img = in;

	setPreferredSize(new Dimension(m_img.getWidth(),
				       m_img.getHeight()));


	update(true, false);
    }

    public void saveAs(String filename) {
	try {
	    ImageIO.write(m_img, "jpg", new File(filename));
	} catch (Exception e) {
	    JOptionPane.showMessageDialog(null, e.toString(), "Error", JOptionPane.ERROR_MESSAGE);
	    System.err.println(e);
	}
    }

    protected void paintComponent(Graphics g) {
	super.paintComponent(g);

	g.drawImage(m_img, 0, 0, null, null);
	if (m_mustShowEnergy) {
	    g.drawImage(m_energy_img, 0, 0, null, null);
	}
    }

    public class defaultComponentAdapter extends ComponentAdapter {
	public void componentResized(ComponentEvent e) {
	    repaint();
	}
    }
	
    /// fonction main de test....
    public static void main(String[] args) {
	final JFrame f = new JFrame("Smart-resizing");
	String filename = "";

	if (args.length == 0) {
	    FileDialog fd = new FileDialog(f, "Choose an image file...", FileDialog.LOAD);
	    fd.setModal(true);
	    fd.setVisible(true);
	    if (fd.getFile() != null)
		filename = fd.getFile();
	} else {
	    filename = args[0];
	}

	final SmartResizing sr = new SmartResizing(filename, new EnergyFunctionGradientwSobelMax());

	f.setLayout(new BorderLayout());
	f.add(new JScrollPane(sr), BorderLayout.CENTER);
	
	JMenuBar menuBar = new JMenuBar();;
	JMenu menu = new JMenu("Energy Function");
	JMenuItem mi;
	
	mi = new JMenuItem("Gradiant Sobel Max");
	mi.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    sr.setEnergyFunction(new EnergyFunctionGradientwSobelMax());
		}
	    });
	menu.add(mi);

	mi = new JMenuItem("Gradiant Sobel Avg");
	mi.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    sr.setEnergyFunction(new EnergyFunctionGradientwSobelAvg());
		}
	    });
	menu.add(mi);

	
	menuBar.add(menu);
	f.setJMenuBar(menuBar);
	

	JPanel p = new JPanel();
	f.add(p, BorderLayout.SOUTH);
	JButton m = new JButton("h-");
	m.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    sr.removev();
		    sr.update(false, true);
		}
	    });
	p.add(m);
	
	m = new JButton("v-");
	m.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    sr.removeh();
		    sr.update(false, true);
		}
	    });
	p.add(m);

	m = new JButton("Show energy funtion");
	m.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    sr.toogleShowEnergyImage();
		}
	    });
	p.add(m);

	m = new JButton("Save");
	m.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    FileDialog fd = new FileDialog(f, "", FileDialog.SAVE);
		    fd.setModal(true);
		    fd.setVisible(true);
		    if (fd.getFile() != null)
			sr.saveAs(fd.getFile());
		}
	    });
	p.add(m);

	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	// 50 * 20
	f.setBounds(0, 0, 500, 200);
	f.setVisible(true);
    }
}
