/**
 * Auteur : Pierre-Francois L�on (leon(at)sic.univ-poitiers.fr)
 * 
 * Implantation bourrin en Java de l'article "Seam Carving for Content-Aware Image Resizing" (Shai Avidan, Ariel Shamir)
 */

import java.awt.image.*;

class EnergyFunctionGradientwSobelAvg extends EnergyFunction {
    public int[][] compute(BufferedImage img) {
	float[] vfilter = new float[] {
	    1, 0, -1,
	    2, 0, -2,
	    1, 0, -1
	};
	float[] hfilter = new float[] {
	    1, 2, 1,
	    0, 0, 0,
	    -1, -2, -1
	};
	Kernel vkernel = new Kernel(3, 3, vfilter);
	ConvolveOp vconvolveOp = new ConvolveOp(vkernel);
	BufferedImage vbi = vconvolveOp.filter(img, new BufferedImage(img.getWidth(), 
								      img.getHeight(), 
								      img.getType()));
	Kernel hkernel = new Kernel(3, 3, hfilter);
	ConvolveOp hconvolveOp = new ConvolveOp(hkernel);
	BufferedImage hbi = hconvolveOp.filter(img, new BufferedImage(img.getWidth(), 
								      img.getHeight(), 
								      img.getType()));

	int res[][] = new int[img.getWidth() - 2][img.getHeight() - 2];
	int v, h;
	for (int i = 1; i < img.getWidth() - 1; ++i)
	    for (int j = 1; j < img.getHeight() - 1; ++j) {
		v = vbi.getRGB(i, j);
		v = ((v & 0xff) + ((v >> 8) & 0xff) + ((v >> 16) & 0xff)) / 3;
		h = hbi.getRGB(i, j);
		h = ((h & 0xff) + ((h >> 8) & 0xff) + ((h >> 16) & 0xff)) / 3;

 		res[i - 1][j - 1] = (v + h) / 2;
	    }
	
	return res;
    }
}
